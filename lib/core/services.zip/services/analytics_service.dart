import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/foundation.dart';

class AnalyticsService {
  static final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  static bool _analyticsEnabled = true;

  static void setAnalyticsEnabled(bool enabled) {
    _analyticsEnabled = enabled;
  }

  static Future<void> trackScreen(String screenName) async {
    if (!_analyticsEnabled) return;

    await _analytics.logScreenView(
      screenName: screenName,
      screenClass: screenName,
    );
  }

  static Future<void> login(String method) async {
    if (!_analyticsEnabled) return;

    await _analytics.logLogin(loginMethod: method);
  }

  static Future<void> logout() async {
    if (!_analyticsEnabled) return;

    await _analytics.logEvent(
      name: "logout",
    );
  }

  static Future<void> signUp(String method) async {
    if (!_analyticsEnabled) return;

    await _analytics.logSignUp(signUpMethod: method);
  }

  static Future<void> buttonClick(String name) async {
    if (!_analyticsEnabled) return;

    await _analytics.logEvent(
      name: "button_click",
      parameters: {
        "button_name": name,
      },
    );
  }

  static Future<void> errorEvent(String message) async {
    if (!_analyticsEnabled) return;

    await _analytics.logEvent(
      name: "error_event",
      parameters: {
        "error_message": message,
      },
    );
  }

  static Future<void> setUserProperties({
    required String userType,
    required String appVersion,
    required String platform,
  }) async {
    if (!_analyticsEnabled) return;

    await _analytics.setUserProperty(
      name: "user_type",
      value: userType,
    );

    await _analytics.setUserProperty(
      name: "app_version",
      value: appVersion,
    );

    await _analytics.setUserProperty(
      name: "platform",
      value: platform,
    );
  }
}