// import 'package:firebase_remote_config/firebase_remote_config.dart';
// import 'package:package_info_plus/package_info_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher.dart';

// class AppVersionService {

//   static Future<void> checkVersion(BuildContext context) async {

//     final remoteConfig = FirebaseRemoteConfig.instance;

//     await remoteConfig.setConfigSettings(
//       RemoteConfigSettings(
//         fetchTimeout: const Duration(seconds: 10),
//         minimumFetchInterval: const Duration(seconds: 0),
//       ),
//     );

//     await remoteConfig.fetchAndActivate();

//     final bool maintenance = remoteConfig.getBool("maintenance_mode");
//     final String minVersion = remoteConfig.getString("min_version");
//     final String latestVersion = remoteConfig.getString("latest_version");
//     final String updateUrl = remoteConfig.getString("update_url");

//     final packageInfo = await PackageInfo.fromPlatform();
//     final String currentVersion = packageInfo.version;

//     /// Maintenance mode
//     if (maintenance) {
//       _showMaintenanceDialog(context);
//       return;
//     }

//     /// Force update
//     if (_isVersionLower(currentVersion, minVersion)) {
//       _showForceUpdate(context, updateUrl);
//       return;
//     }

//     /// Optional update
//     if (_isVersionLower(currentVersion, latestVersion)) {
//       _showOptionalUpdate(context, updateUrl);
//     }
//   }

//   static bool _isVersionLower(String current, String remote) {

//     List<int> currentParts =
//         current.split('.').map((e) => int.tryParse(e) ?? 0).toList();

//     List<int> remoteParts =
//         remote.split('.').map((e) => int.tryParse(e) ?? 0).toList();

//     int maxLength = currentParts.length > remoteParts.length
//         ? currentParts.length
//         : remoteParts.length;

//     for (int i = 0; i < maxLength; i++) {

//       int currentValue = i < currentParts.length ? currentParts[i] : 0;
//       int remoteValue = i < remoteParts.length ? remoteParts[i] : 0;

//       if (currentValue < remoteValue) return true;
//       if (currentValue > remoteValue) return false;
//     }

//     return false;
//   }

//   static void _showForceUpdate(BuildContext context, String url) {

//     showDialog(
//       barrierDismissible: false,
//       context: context,
//       builder: (_) => AlertDialog(
//         title: const Text("Update Required"),
//         content: const Text(
//             "A new version of the app is required to continue."),
//         actions: [
//           ElevatedButton(
//             onPressed: () => _openStore(url),
//             child: const Text("Update"),
//           )
//         ],
//       ),
//     );
//   }

//   static void _showOptionalUpdate(BuildContext context, String url) {

//     showDialog(
//       context: context,
//       builder: (_) => AlertDialog(
//         title: const Text("Update Available"),
//         content: const Text(
//             "A new version of the app is available."),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text("Later"),
//           ),
//           ElevatedButton(
//             onPressed: () => _openStore(url),
//             child: const Text("Update"),
//           ),
//         ],
//       ),
//     );
//   }

//   static void _showMaintenanceDialog(BuildContext context) {

//     showDialog(
//       barrierDismissible: false,
//       context: context,
//       builder: (_) => const AlertDialog(
//         title: Text("Maintenance"),
//         content: Text(
//             "The system is currently under maintenance. Please try again later."),
//       ),
//     );
//   }

//   static Future<void> _openStore(String url) async {

//     if (url.isEmpty) return;

//     final Uri uri = Uri.parse(url);

//     if (await canLaunchUrl(uri)) {
//       await launchUrl(uri, mode: LaunchMode.externalApplication);
//     }
//   }
// }

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class AppUpdateService {

  static Future<void> checkVersion(BuildContext context) async {

    final remoteConfig = FirebaseRemoteConfig.instance;

    await remoteConfig.setConfigSettings(
      RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 10),
        minimumFetchInterval: const Duration(seconds: 0),
      ),
    );

    await remoteConfig.fetchAndActivate();

    bool maintenanceMode = remoteConfig.getBool("maintenance_mode");
    String minVersion = remoteConfig.getString("min_version");
    String latestVersion = remoteConfig.getString("latest_version");
    String updateUrl = remoteConfig.getString("update_url");

    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String currentVersion = packageInfo.version;

    /// Maintenance Mode
    if (maintenanceMode) {
      _showMaintenance(context);
      return;
    }

    /// Force Update
    if (_isLower(currentVersion, minVersion)) {
      _showForceUpdate(context, updateUrl);
      return;
    }

    /// Optional Update
    if (_isLower(currentVersion, latestVersion)) {
      _showOptionalUpdate(context, updateUrl);
    }
  }

  static bool _isLower(String current, String remote) {

    List<int> currentParts =
        current.split('.').map(int.parse).toList();

    List<int> remoteParts =
        remote.split('.').map(int.parse).toList();

    for (int i = 0; i < remoteParts.length; i++) {

      if (currentParts[i] < remoteParts[i]) return true;
      if (currentParts[i] > remoteParts[i]) return false;

    }

    return false;
  }

  static void _showForceUpdate(BuildContext context, String url) {

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Update Required"),
        content: const Text(
          "A new version of the app is required to continue."
        ),
        actions: [
          ElevatedButton(
            onPressed: () => _openStore(url),
            child: const Text("Update"),
          )
        ],
      ),
    );
  }

  static void _showOptionalUpdate(BuildContext context, String url) {

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Update Available"),
        content: const Text(
          "A new version of the app is available."
        ),
        actions: [

          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Later"),
          ),

          ElevatedButton(
            onPressed: () => _openStore(url),
            child: const Text("Update"),
          )

        ],
      ),
    );
  }

  static void _showMaintenance(BuildContext context) {

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (_) => const AlertDialog(
        title: Text("Maintenance"),
        content: Text(
          "The system is currently under maintenance. Please try again later."
        ),
      ),
    );
  }

  static Future<void> _openStore(String url) async {

    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }
}