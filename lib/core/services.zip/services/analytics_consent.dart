import 'analytics_service.dart';

class AnalyticsConsent {

  static bool consentGiven = false;

  static void giveConsent() {
    consentGiven = true;
    AnalyticsService.setAnalyticsEnabled(true);
  }

  static void denyConsent() {
    consentGiven = false;
    AnalyticsService.setAnalyticsEnabled(false);
  }

}